// @tapeapi/sdk/connect: `tapeapi connect` as data and text, for the command line and a web page alike. The WHOLE subpath
// is Experimental and outside the package's compatibility promise: it may change or go away in any minor version.
// It reads the chain and the manifest only; it asks for no key or password and sends no transaction.
import type { TapeAPI } from './index.js'

/** @experimental Text in English and Chinese. */
export interface Bilingual { en: string; zh: string }
/** @experimental A tool a settings snippet is written for. */
export type SnippetTool = 'openai-sdk' | 'curl' | 'codex' | 'claude-code' | 'claude-desktop'
/** @experimental One client setting: `via` 'sdk' (createVerifyingFetch in the caller's process), 'proxy' (through tapeapi-verify), 'stdio' (an MCP tool service through tapeapi-mcp) or 'direct' (not checked); `verifies` is false for 'direct'. An MCP setting has `format` 'mcp'. */
export interface Snippet { tool: SnippetTool; format: string; via: 'sdk' | 'proxy' | 'stdio' | 'direct'; verifies: boolean; title: Bilingual; text: string }
/** @experimental Each AI tool and the API formats it needs; a tool gets a snippet only for a format the manifest declares. */
export declare const SNIPPET_TOOLS: Readonly<Record<Exclude<SnippetTool, 'claude-desktop'>, readonly string[]>>
/** @experimental The tools an MCP tool service's settings are written for. */
export declare const MCP_SNIPPET_TOOLS: readonly ('claude-code' | 'claude-desktop')[]
/** @experimental The fixed sentences of an MCP tool service's card. */
export declare const MCP_NOTES: Readonly<{ receipt: Bilingual; tools: Bilingual; boundary: Bilingual }>
/**
 * @experimental MCP client settings for an MCP tool service (no `ai` field, a valid `mcp` field, TAPI-20 §3.8): Claude
 * Code and Claude Desktop through tapeapi-mcp, then the declared endpoint direct. [] otherwise. No key is written. Pure.
 */
export declare function mcpSnippetsFor(manifest: { ai?: unknown; mcp?: { endpoint: string; toolsSha256: string } } | null | undefined, o?: {
  target?: string
  dev?: string | null
  /** the SDK release whose package npx runs */
  version?: string
  tool?: 'claude-code' | 'claude-desktop' | 'all'
}): Snippet[]
/** @experimental The format names this SDK knows. */
export declare const FORMAT_NAMES: readonly string[]
/** @experimental The fixed sentences of every card: what a receipt proves, what a price is, the command's boundary, the token. */
export declare const NOTES: Readonly<{ receipt: Bilingual; prices: Bilingual; boundary: Bilingual; token: Bilingual }>
/**
 * @experimental Client settings for an AI service, only for the formats its manifest's ai.endpoints declares, in that
 * order. The token is never written: snippets read the environment variable API_KEY. Pure (no I/O).
 */
export declare function snippetsFor(manifest: { ai?: { endpoints?: { format: string; baseUrl: string }[]; models?: { id: string; formats?: string[] }[] } } | null | undefined, o?: {
  target?: string
  /** a development sidecar URL in place of `target` (testing only: no on-chain identity check) */
  dev?: string | null
  /** the local proxy's port (default 8790) */
  port?: number
  /** the command that starts the proxy (default `tapeapi connect <target> --proxy`) */
  proxyCommand?: string
  tool?: SnippetTool | 'all'
  format?: string
}): Snippet[]
/** @experimental What connectReport found: `exitCode` 0 usable, 1 unavailable (status and reason say why), 2 a usage mistake, 3 could not be read. */
export interface ConnectReport {
  target: string
  dev: boolean
  resolution: 'tap10' | 'dev'
  ok: boolean
  exitCode: 0 | 1 | 2 | 3
  /** 'ok', a TAP status ('unpaid', 'not-opened', 'store-changed', 'no-manifest', 'delegation-invalid', 'unavailable', ...), 'not-ai', 'ai-invalid', 'mcp-invalid' or 'not-declared' */
  status: string | null
  /** what the service is once its manifest says so: 'ai' (an ai field), 'mcp' (no ai field, a valid mcp field); null otherwise */
  kind: 'ai' | 'mcp' | null
  reason: Bilingual | null
  detail: string | null
  service: {
    name?: string | null
    tapeName?: string | null
    chainId?: number | null
    chain?: string | null
    container?: string | null
    holder?: string | null
    signer?: string | null
    delegationExpires?: number | null
    activation?: { live: boolean; isLive: boolean | null; isContainerLive: boolean } | null
    endpoints?: { format: string; baseUrl: string }[]
    models?: { id: string; aliases?: string[]; formats?: string[]; prices: Record<string, string>[] }[]
    /** an MCP tool service only: its declared endpoint and digest, and `tools`: the names of the manifest's free methods,
     *  the ones tapeapi-mcp can offer (it offers no priced method). They are candidates, not necessarily tools: a method
     *  is a tool only if the endpoint's tools/list has a tool of its name, which tapeapi-mcp checks and connect does not
     *  (a manifest may bind only some of its methods, TAP-15 §4.1); the card calls them methods (2.4) */
    mcp?: { endpoint: string; toolsSha256: string }
    tools?: string[]
  } | null
  formats: string[]
  snippets: Snippet[]
}
/**
 * @experimental Resolve `target` with `api` (a client built with conform: 'tap10' shows unpaid, not-opened and
 * store-changed as such) and describe it; never throws for a service that cannot be used.
 */
export declare function connectReport(target: string | null, o: { api: Pick<TapeAPI, 'resolve'>; dev?: string | null; tool?: SnippetTool | 'all'; format?: string; port?: number; proxyCommand?: string; version?: string }): Promise<ConnectReport>
/** @experimental The card as terminal text; colors only on the status words and headings; `next` ends any exit other than 0. */
export declare function renderConnect(report: ConnectReport, o?: { lang?: 'en' | 'zh' | 'both'; color?: boolean; version?: string; now?: number; next?: string | null; nextHint?: Bilingual | null }): string
