// @tapeapi/server：Provider 运行时 / Provider runtime: manifest, health, paid+free method dispatch, signed envelopes.
import { createRpc, TapeAPIError, validateManifest, safeParseJSON, canonicalJSON, parseUnits, BEM_DECIMALS, METHOD_NAME_RE, abi, sig, usdPricing as UP, MAINNET } from '@tapeapi/sdk'

const { encodeCall, decodeReturn, isAddress, eqAddr, checksumAddress } = abi
const { voucherDigest, recoverAddress, signResponse, privateKeyToAddress, recoverVoucherSigner, recoverResponseSigner } = sig
// A literal, not a package.json read: `createRequire` is a node:module import, and importing it at module scope
// would stop this runtime loading on Cloudflare Workers, Deno or a browser. A test asserts the two agree.
// 写成字面量而不是读 package.json：`createRequire` 属于 node:module，在模块顶层导入会让这套运行时无法在
// Cloudflare Workers、Deno 或浏览器里加载。有测试断言两者一致。
export const VERSION = '3.0.0'
const now = () => Math.floor(Date.now() / 1000)
const hasOwn = (o, k) => Object.prototype.hasOwnProperty.call(o, k)
// @experimental the marker of ctx.resend(env) / ctx.resend 的标记
const RESEND = Symbol('tapeapi.resend')
const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v)
// The address a configured client-IP header names, one spelling per address, so one client is one rate-limit key
// (FIXED IP-CANON: '::FFFF:1.2.3.4', '0:0::ffff:102:304' and '1.2.3.4' were three keys). IPv4 in dotted decimal (no leading
// zeros, as Node's net.isIP), IPv6 as the WHATWG URL parser writes it (lowercase, zeros compressed), an IPv4-mapped IPv6
// address as its IPv4; anything else is 'unknown'. No node:net: handleRequest runs on Workers too.
// 配置的客户端 IP 头所指的地址，每个地址只有一种写法，一个客户端只占一个限流键。IPv4 为点分十进制（无前导零），IPv6 按 URL 解析器
// 的写法（小写、压缩零），IPv4 映射的 IPv6 地址写成 IPv4；其它一律为 'unknown'。不用 node:net：handleRequest 也跑在 Workers 上。
function canonicalIp(value) {
  const v = String(value ?? '').trim()
  const m4 = /^(0|[1-9]\d{0,2})\.(0|[1-9]\d{0,2})\.(0|[1-9]\d{0,2})\.(0|[1-9]\d{0,2})$/.exec(v)
  if (m4) return m4.slice(1).every((o) => Number(o) <= 255) ? v : 'unknown'
  if (v.length > 45 || !v.includes(':') || !/^[0-9A-Fa-f:.]+$/.test(v)) return 'unknown'
  let a
  try { a = new URL(`http://[${v}]/`).hostname.slice(1, -1) } catch { return 'unknown' }
  const mapped = /^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/.exec(a)
  if (!mapped) return a
  const hi = parseInt(mapped[1], 16), lo = parseInt(mapped[2], 16)
  return [hi >> 8, hi & 255, lo >> 8, lo & 255].join('.')
}

// 默认内存 store / Default in-memory voucher store.
export function memoryStore() {
  const m = new Map()
  const k = (c, p) => `${c.toLowerCase()}:${p.toLowerCase()}`
  return {
    async get(c, p) { return m.get(k(c, p)) || null },
    async set(c, p, rec) { m.set(k(c, p), rec) },
    async all() { return [...m.values()] },
    // Atomic monotonic write-back: store `rec` only if it moves the counter up, and say whether it did.
    // Read-then-write is not good enough -- it is the classic lost update, and across two processes it is also
    // how one voucher gets served twice (x402's "248 grants from one payment"). A store that spans instances
    // MUST implement this as one statement, e.g. SQL `UPDATE ... WHERE cumulative < ?`.
    // 原子单调写回：仅当推高了计数器才写入，并返回是否推高。读后写不够用——那是经典的丢失更新，
    // 跨进程时还正是"一张凭证被服务两次"的成因。跨实例的 store MUST 用单条语句实现，例如 SQL 的条件更新。
    async advance(c, p, rec) {
      const key = k(c, p)
      const cur = m.get(key)
      if (cur && BigInt(cur.cumulative) >= BigInt(rec.cumulative)) return false
      m.set(key, rec)
      return true
    },
  }
}

// @experimental (TAP draft "Payment Vouchers" §4.4): the quotes a service has stated, so that every instance honours
// every one of them until its validUntil. put(quote, container) / get(rate, container): the quote with that rate string
// and the latest validUntil for that service (the container), or null; one store can serve several services (review S8).
// Instances behind one URL MUST share one store (a table keyed by container and rate); this default is per process.
// @experimental 服务说过的报价，使每个实例在 validUntil 之前都兑现每一个。按服务（容器）与汇率字符串建键，一个 store 可服务多个服务。
// 同一 URL 后面的实例 MUST 共用一个 store；默认只在本进程。
export function memoryQuoteStore() {
  const m = new Map()
  const key = (container, rate) => `${String(container ?? '').toLowerCase()}|${rate}`
  return {
    async put(q, container) {
      const k = key(container, q.rate), cur = m.get(k)
      if (!cur || cur.validUntil < q.validUntil) m.set(k, { rate: q.rate, asOf: q.asOf, validUntil: q.validUntil })
      if (m.size > 4096) { const t = Math.floor(Date.now() / 1000); for (const [x, v] of m) if (v.validUntil < t) m.delete(x) }
    },
    async get(rate, container) { return m.get(key(container, rate)) || null },
  }
}

// createProvider 的选项 / createProvider options:
//   manifest, signerKey, methods   必填三件套；methods 必须为清单里每个方法提供一个处理函数
//                                  the required trio; `methods` needs one handler per manifest method
//   rpcUrls, quorum, timeoutMs, fetch, allowSingleNode   链读（无 rpcUrls 则不读链，收费方法无法校验凭证）
//                                  chain reads; without rpcUrls there are none, and vouchers cannot be checked
//   rpcRetries                     @experimental (2.3) as createRpc's: extra rounds for a chain read whose round failed fast
//                                  and only by the network (default: the SDK's, 2; 0 turns it off) / 与 createRpc 同义：
//                                  某轮只因网络故障且很快失败的链读再问几轮（默认取 SDK 的 2；0 关闭）
//   dev / allowHttp                接受 http:// 端点（仅开发）/ accept http:// endpoints (development only)
//   escrow, chainId                覆盖清单里的托管合约与链 / override the manifest's escrow and chain
//   escrowToken                    托管 token() 的预期值，默认 BSC 上为 BEM；listen() 在不一致时拒绝启动（托管代币核对）
//                                  the token() the escrow must hold, BEM on BNB Smart Chain by default; listen() refuses to
//                                  start when it differs (the escrow token check); checkEscrowToken() for a Worker
//   store                          凭证存储，默认进程内存 / voucher store, in-process memory by default
//   allowMemoryStore, warn         非 dev 的收费服务用默认内存 store 时会 console.warn（或 warn）；allowMemoryStore: true 表示有意为之
//                                  a non-dev priced service on the default in-memory store console.warns (or calls
//                                  `warn`); allowMemoryStore: true says you meant it (arch A1)
//   log, bodyLimit
//   escrowCacheMs, sessionCacheMs, blockCacheMs, contributionCacheMs, cacheMax   链读缓存 / chain-read caches
//   withdrawCloseS                 提现请求可执行窗口的关闭时间，默认 9d = WITHDRAW_COOLDOWN (48h) + WITHDRAW_WINDOW (7d)；
//                                  只有把这两个常量设成别的值的托管合约才需要覆盖它。
//                                  When a withdraw request stops being executable; only an escrow deployed with
//                                  different constants needs to override the 9-day default.
//   @experimental (TAP draft "Payment Vouchers", TAPs#52; only for a manifest with the top-level member `usdPricing`)
//   usdRate                        async () => ({ rate, asOf }): the rate (USD per 1 BEM, a string of §4.4 or a number) and
//                                  the end of its averaging period; default: the median of the manifest's own rateSources
//                                  read under node agreement (rpcUrls needed) / 汇率来源，默认读清单自己列的来源
//   quoteValidS                    how long a quote stays valid, at most usdPricing.maxQuoteS (the default)
//   quoteStore                     { put(quote), get(rate) } shared by every instance (memoryQuoteStore() per process)
//   settlementFacts                { amountPaid(consumer), fundsAvailable(consumer), keyAuthorisedUntil(consumer, key) }:
//                                  F2, F4 and F3 of the draft's §2.2 from configuration instead of the TapeAPIEscrow reads,
//                                  until a settlement TAP names the functions. Any manifest. / 结算 TAP 之前由配置提供 F2–F4
export function createProvider(opts = {}) {
  // 1.0 (review G1 S4): as in createTapeAPI, the RPC timeout is `rpcTimeoutMs` (beside handlerTimeoutMs, requestTimeoutMs,
  // headersTimeoutMs). / 与 createTapeAPI 一致，RPC 超时叫 rpcTimeoutMs。
  if (Object.prototype.hasOwnProperty.call(opts, 'timeoutMs')) throw new TapeAPIError('INVALID_ARGUMENT', 'the option `timeoutMs` of createProvider was renamed `rpcTimeoutMs` in 1.0 (the timeout of one RPC request): see https://tapeapi.fun/docs/en/upgrade-1.0')
  const { signerKey, methods = {}, rpcUrls = [], quorum = 2, fetch: fetchImpl, rpcTimeoutMs: timeoutMs } = opts
  if (!signerKey) throw new TapeAPIError('INVALID_ARGUMENT', 'signerKey required')
  const manifest = opts.manifest // 保留引用，方便调用方后续补 endpoints / keep the reference (caller may patch endpoints later)
  // 1.0 (review G1 S2): `dev` alone relaxes the payment checks (priced methods on a zero-address escrow, the in-memory meter
  // warning); `allowHttp` only allows http endpoints (dev implies it). A manifest's own `dev` field switches nothing:
  // it is published data, not configuration. / `dev` 只由 opts.dev 决定；allowHttp 只管 http；清单里的 dev 字段不再起作用。
  const devMode = opts.dev === true
  const allowHttp = devMode || opts.allowHttp === true
  // validateManifest exempts a zero escrow only for a manifest that says `dev: true`; here that follows opts.dev alone
  // (review P2-F7), on a copy, so the manifest served is exactly the one given.
  // validateManifest 只对写了 dev: true 的清单豁免零地址托管；这里只按 opts.dev 决定（在副本上），对外提供的仍是原清单。
  const normalized = validateManifest(devMode && manifest && typeof manifest === 'object' ? { ...manifest, dev: true } : manifest, { requireDelegation: false, allowHttp })
  // An already-expired delegation serves responses that every consumer rejects. Refuse to boot rather than
  // look healthy for hours. The consumer side keeps its own, more precise DELEGATION_INVALID.
  // 已过期的委托会一直发出所有消费者都拒绝的响应。宁可拒绝启动，也不要看起来健康地空转几小时。
  // （冷启动测试 2026-09-21 发现）
  if (manifest?.delegation && Number.isInteger(manifest.delegation.expires) && manifest.delegation.expires <= Math.floor(Date.now() / 1000)) {
    throw new TapeAPIError('DELEGATION_INVALID', `manifest.delegation.expires ${manifest.delegation.expires} is in the past; re-sign the delegation before serving`)
  }
  // ...and the same once it lapses WHILE serving (arch A3): a process that booted in time kept signing answers every
  // consumer rejects. Read live from the manifest, which the operator may re-sign in place. Nothing is signed after
  // it: the refusal is an unsigned 503 DELEGATION_INVALID, the code a consumer would give.
  // ……运行中过期也一样（arch A3）：按时启动的进程此前会继续签发所有消费者都拒绝的回答。每次都从清单现读，运营者可以就地重签。
  // 过期后什么都不签：拒绝是未签名的 503 DELEGATION_INVALID，与消费者给出的错误码相同。
  const delegationExpires = () => (Number.isInteger(manifest?.delegation?.expires) ? manifest.delegation.expires : null)
  const delegationLapsed = () => { const x = delegationExpires(); return x != null && x <= now() }
  const lapsedError = () => ({ ok: false, error: { code: 'DELEGATION_INVALID', message: `this provider's delegation expired at ${delegationExpires()}; the holder must re-sign it`, data: { delegationExpires: delegationExpires() } } })
  const signerAddr = privateKeyToAddress(signerKey)
  if (!eqAddr(signerAddr, manifest.signer)) throw new TapeAPIError('BAD_KEY', `signerKey derives ${signerAddr} but manifest.signer is ${manifest.signer}`)
  const chainId = opts.chainId ?? 56
  // Consumers sign vouchers against the escrow the MANIFEST names (it is the EIP-712 verifyingContract), so an
  // override may only restate it. A different one would verify no voucher, and a zero one would dodge the
  // zero-escrow refusal above (runtime audit I-03).
  // 消费者按清单里的托管签凭证（EIP-712 verifyingContract），覆盖值只能与之相同；不同的验不过任何凭证，零地址会绕过上面的拒绝。
  if (opts.escrow != null) {
    if (!isAddress(opts.escrow)) throw new TapeAPIError('INVALID_ARGUMENT', `opts.escrow ${opts.escrow} is not an address`)
    if (normalized.payment.escrow && !eqAddr(opts.escrow, normalized.payment.escrow)) {
      throw new TapeAPIError('INVALID_ARGUMENT', `opts.escrow ${opts.escrow} differs from manifest payment.escrow ${normalized.payment.escrow}; consumers sign against the manifest's`)
    }
  }
  const escrow = opts.escrow ?? normalized.payment.escrow
  if (opts.escrowToken !== undefined && !isAddress(opts.escrowToken)) throw new TapeAPIError('INVALID_ARGUMENT', `opts.escrowToken ${opts.escrowToken} is not an address`)
  const anyPriced = normalized.methods.some((x) => x.priceBEM !== '0')
  const hasEscrow = escrow != null && !eqAddr(escrow, '0x0000000000000000000000000000000000000000')
  if (anyPriced && !hasEscrow && !devMode) throw new TapeAPIError('MANIFEST_INVALID', 'priced methods need a real escrow (payment.escrow or opts.escrow), or createProvider({ dev: true }) for local testing')
  const container = checksumAddress(manifest.container)
  const store = opts.store || memoryStore()
  // 2.3: rpcRetries passed only when given, so createRpc's default (retrying, 2) applies otherwise and its own check
  // refuses a bad value. / 只在给出时传，否则用 createRpc 的默认值（重试，2）；非法值由它自己拒绝。
  const rpc = rpcUrls.length ? createRpc({ urls: rpcUrls, quorum, timeoutMs, fetch: fetchImpl, allowSingleNode: opts.allowSingleNode === true,
    ...(opts.rpcRetries !== undefined ? { rpcRetries: opts.rpcRetries } : {}) }) : null
  const bodyLimit = opts.bodyLimit ?? 64 * 1024
  const hardBodyCap = Math.max(bodyLimit * 64, 4 * 1024 * 1024)
  // TAPI-21 §3.2: providers MUST cap the response body at 1 MiB and SHOULD answer within 30 s.
  // TAPI-21 §3.2：响应体 MUST 不超过 1 MiB，SHOULD 在 30 秒内作答。
  const RESPONSE_LIMIT = 1024 * 1024
  const handlerTimeoutMs = Number(opts.handlerTimeoutMs ?? 25_000)   // drained and refused below this, cut off above it / 此值以下读完再拒，以上直接断开
  const escrowCacheMs = opts.escrowCacheMs ?? 30_000
  const sessionCacheMs = opts.sessionCacheMs ?? 60_000
  const blockCacheMs = opts.blockCacheMs ?? 3_000
  // A2-02: vouchers and session keys are dated by the consumer. Anything that dies before this provider can
  // mine a settlement is free service. Both deadlines must have at least this much life left at verification;
  // the operator's settler cadence MUST be shorter than this value (see pendingSettlements / settleTx).
  // A2-02：凭证与会话密钥的期限都由消费者选。在本提供者来得及上链结算前就失效的，等于白干。
  // 两个期限在校验时都必须至少还剩这么久；运营方的结算频率 MUST 短于此值。
  const minVoucherLifeS = Number(opts.minVoucherLifeS ?? 300)
  // Rate limiting. Free methods carry no identity and no cost, so without this a provider's free tier is an
  // open invitation: one laptop saturates it. Paid calls carry the consumer address, which is a far better key
  // than an IP, so they get their own, higher budget. 0 on either disables that half.
  // 限流。免费方法既没有身份也没有成本，没有这一层，提供者的免费层就是敞开的：一台笔记本就能打满。
  // 付费调用带着消费者地址，这个键比 IP 好得多，因此单独给一份更高的预算。任一项为 0 即关闭该半边。
  const rl = opts.rateLimit === false ? null : {
    windowMs: Number(opts.rateLimit?.windowMs ?? 60_000),
    free: Number(opts.rateLimit?.free ?? 600),
    paid: Number(opts.rateLimit?.paid ?? 6000),
    max: Number(opts.rateLimit?.max ?? 50_000),
  }
  // A per-IP flood ceiling applied before the body is read. It must sit above free + paid, or one consumer making
  // its paid calls and a few free ones would be refused by its own IP; several consumers behind one NAT share it.
  // 在读 body 之前按 IP 生效的洪水上限。它必须高于免费加付费，否则一个消费者在付费调用之外再发几个免费请求，
  // 就会被自己的 IP 拒绝；同一 NAT 后面的多个消费者共享这个上限。
  if (rl) rl.ip = Number(opts.rateLimit?.ip ?? rl.free + rl.paid)
  // @experimental (TAP draft, review S4): a priced call without a voucher to a service with usdPricing is the client asking
  // for a quote; it has its own budget per IP (default: the free budget), so a caller willing to pay is not refused for
  // having spent the free one. / 带 usdPricing 的服务上，计价方法的无凭证请求是在要报价：按 IP 单独预算（默认同免费预算）
  if (rl) rl.quote = Number(opts.rateLimit?.quote ?? rl.free)
  // Numbers, validated at boot: a negative budget would refuse everything and NaN would silently switch a half off.
  // 0 is allowed and means "this half is off". / 启动时校验：负数会拒绝一切，NaN 会悄悄关掉某一半；0 表示关闭该半边。
  if (rl) {
    for (const k of ['free', 'paid', 'ip', 'max', 'quote']) if (!Number.isInteger(rl[k]) || rl[k] < 0) throw new TapeAPIError('INVALID_ARGUMENT', `rateLimit.${k} must be a non-negative integer`)
    if (!Number.isInteger(rl.windowMs) || rl.windowMs <= 0) throw new TapeAPIError('INVALID_ARGUMENT', 'rateLimit.windowMs must be a positive integer')
  }
  // Which header identifies the caller when the process sits behind a proxy. UNSET BY DEFAULT: trusting a
  // client-settable header without a trusted proxy in front turns the limiter into a no-op, since the attacker
  // picks its own key. Set it to 'cf-connecting-ip' behind Cloudflare, 'x-forwarded-for' behind exactly ONE proxy of
  // your own. For a list-valued header the LAST entry is used -- the one your proxy appended; the leftmost is
  // whatever the client wrote (runtime audit F-03).
  // 进程位于代理之后时用哪个头识别调用方。默认不设。Cloudflare 后面设 'cf-connecting-ip'，恰好一层自建代理后面设
  // 'x-forwarded-for'。列表形式的头取**最后**一项，即你的代理追加的那一项；最左边那项是客户端自己写的。
  const clientIpHeader = typeof opts.clientIpHeader === 'string' ? opts.clientIpHeader.toLowerCase() : null
  const lastHop = (v) => { const parts = String(v || '').split(',').map((x) => x.trim()).filter(Boolean); return parts.length ? parts[parts.length - 1] : '' }
  // The configured header's last hop as one canonical address ('' when the header is absent, 'unknown' when it is not an
  // address). / 配置头最后一跳的规范地址（头不存在为 ''，不是地址为 'unknown'）。
  let warnedBadIp = false
  const headerIp = (v) => {
    const s = lastHop(v)
    if (!s) return ''
    const ip = canonicalIp(s)
    if (ip === 'unknown' && !warnedBadIp) { warnedBadIp = true; log(`clientIpHeader ${clientIpHeader} carried a value that is not an IP address; callers sending such values share the rate-limit bucket "unknown"`) }
    return ip
  }
  const FAIL_BUDGET = 20   // failed paid attempts per window before an IP out of free budget is refused up front / 每窗口失败的付费尝试次数上限
  if (!Number.isInteger(minVoucherLifeS) || minVoucherLifeS < 0) throw new TapeAPIError('INVALID_ARGUMENT', 'minVoucherLifeS must be a non-negative integer')
  const contributionCacheMs = opts.contributionCacheMs ?? 60_000
  const cacheMax = opts.cacheMax ?? 10_000
  const log = opts.log || (() => {})
  // Boot warnings the operator should see before a consumer does / 运营者应当先于消费者看到的启动警告
  if (anyPriced && !hasEscrow) log('dev manifest with priced methods and no escrow: paid calls are refused with INTERNAL until ESCROW is set (or run with FREE_ALL=1)')
  const delegationLeft = Number.isInteger(manifest?.delegation?.expires) ? manifest.delegation.expires - Math.floor(Date.now() / 1000) : null
  if (delegationLeft != null && delegationLeft < 7 * 86400) log(`delegation expires in ${Math.floor(delegationLeft / 3600)} h; every response is rejected after that, re-sign it soon`)
  // Without an atomic `advance`, two processes behind one URL lose meter updates to each other and can serve the
  // same voucher twice. That is a revenue loss for the provider, not a fund-safety problem for the consumer, but
  // it must not be silent: say it at boot and report it in stats().
  // 没有原子的 `advance`，同一个 URL 后面的两个进程会互相丢失计量更新，并可能把同一张凭证服务两次。
  // 那是提供者的收入损失，不是消费者的资金安全问题，但不能悄无声息：启动时说明，并在 stats() 里报告。
  const singleInstance = typeof store.advance !== 'function'
  if (singleInstance) log('store has no advance(): run ONE instance of this provider, or supply a store whose advance() is atomic')
  // A priced, non-dev service on the default meter (arch A1): unsettled vouchers die with the process, and every
  // instance or isolate behind the URL keeps its own meter and serves the same voucher again. Said out loud, not
  // through `log` (which is silent by default).
  // 非 dev 的收费服务用默认计量（arch A1）：未结算凭证随进程消失，URL 后面的每个实例或隔离实例各有一份计量，
  // 会把同一张凭证再服务一次。直接说出来，而不是经由默认静默的 `log`。
  if (anyPriced && !opts.store && !devMode && opts.allowMemoryStore !== true) {
    (opts.warn || ((...a) => console.warn('[tapeapi/server]', ...a)))('priced methods on the in-memory meter: unsettled vouchers are lost on restart, and each instance behind this URL serves the same voucher again. Pass a persistent store with an atomic advance() (e.g. D1), or allowMemoryStore: true if you mean it')
  }

  // ---- @experimental TAP draft "Payment Vouchers" (TAPs#52): prices in US dollars, paid in BEM ----
  // `tap` is null for a manifest without `usdPricing`, and then nothing below changes the 1.8.1 behaviour (the golden
  // test server/test/payment-golden.test.mjs). With it, every priced method of the service follows the draft: BAD_VOUCHER
  // carries `reason`, PAYMENT_REQUIRED carries `minVoucherLifeS`, a voucher's v must be 27 or 28, and every priced result
  // is an object carrying the charge record `charge`. An invalid `usdPricing` refuses to boot: it is the operator's.
  // 没有 `usdPricing` 的清单 `tap` 为 null，下面的一切都不改变 1.8.1 的行为。有它时，该服务的每个计价方法都按草稿：BAD_VOUCHER
  // 带 `reason`、PAYMENT_REQUIRED 带 `minVoucherLifeS`、凭证 v 只能是 27/28、每个计价结果都是带计费记录 `charge` 的对象。
  // `usdPricing` 无效即拒绝启动：那是运营者的清单。
  const tap = UP.validateUsdPricing(manifest, { usdTokens: null })
  const usdMethods = tap ? tap.methods : {}
  // @experimental (phase 1) opts.enforcement: another backend's payment acceptance ({ name, verifyVoucher(voucher, price) }
  // returning a lease { consumer, signer, cumulative, commit(), release() }), for a manifest without usdPricing
  // 另一执行后端的收款核验，只用于不带 usdPricing 的清单
  if (opts.enforcement !== undefined) {
    if (typeof opts.enforcement?.name !== 'string' || typeof opts.enforcement.verifyVoucher !== 'function') throw new TapeAPIError('INVALID_ARGUMENT', 'enforcement must be a payment acceptance { name, verifyVoucher(voucher, price) }')
    if (tap) throw new TapeAPIError('INVALID_ARGUMENT', `enforcement ${opts.enforcement.name} does not apply to a manifest with usdPricing`)
    // its terms (when it states them) must be this manifest's: payment.escrow names its settlement, it pays this container
    // 它的条款（若给出）必须与本清单一致：payment.escrow 写的是它的结算合约，收款方是本容器
    const t = typeof opts.enforcement.terms === 'function' ? opts.enforcement.terms() : null
    if (t && (!hasEscrow || !eqAddr(t.settlement, escrow))) throw new TapeAPIError('INVALID_ARGUMENT', `enforcement ${opts.enforcement.name} settles on ${t.settlement}; the manifest's payment.escrow must name it (it names ${escrow ?? 'none'})`)
    if (t && !eqAddr(t.receiver, container)) throw new TapeAPIError('INVALID_ARGUMENT', `enforcement ${opts.enforcement.name} pays ${t.receiver}, not this container ${container}`)
  }
  const anyUsd = Object.keys(usdMethods).length > 0
  const quoteStore = opts.quoteStore || memoryQuoteStore()
  if (opts.quoteStore && (typeof quoteStore.put !== 'function' || typeof quoteStore.get !== 'function')) throw new TapeAPIError('INVALID_ARGUMENT', 'quoteStore needs put(quote, container) and get(rate, container)')
  const quoteValidS = tap ? Number(opts.quoteValidS ?? tap.maxQuoteS) : 0
  if (tap && (!Number.isInteger(quoteValidS) || quoteValidS < 1 || quoteValidS > tap.maxQuoteS)) throw new TapeAPIError('INVALID_ARGUMENT', `quoteValidS must be an integer from 1 to usdPricing.maxQuoteS (${tap.maxQuoteS})`)
  if (opts.usdRate != null && typeof opts.usdRate !== 'function') throw new TapeAPIError('INVALID_ARGUMENT', 'usdRate must be an async function returning { rate, asOf }')
  if (anyUsd && !rpc && !opts.usdRate) throw new TapeAPIError('INVALID_ARGUMENT', 'usdPricing needs rpcUrls (to read its rateSources) or opts.usdRate')
  if (anyUsd && !opts.quoteStore && !devMode && opts.allowMemoryStore !== true) {
    (opts.warn || ((...a) => console.warn('[tapeapi/server]', ...a)))('USD-priced methods on the in-memory quote store: a quote stated by this instance is not honoured by another instance behind this URL. Pass a shared quoteStore, or allowMemoryStore: true if you run one instance')
  }
  const facts = opts.settlementFacts ?? null
  if (facts != null) for (const k of ['amountPaid', 'fundsAvailable', 'keyAuthorisedUntil']) if (typeof facts[k] !== 'function') throw new TapeAPIError('INVALID_ARGUMENT', `settlementFacts.${k} must be a function`)
  // The current quote: derived from the rate source, stated (stored) before it is ever signed, renewed when half its
  // life is gone. / 当前报价：由汇率来源导出，签进任何回答之前先登记，过了一半寿命就换新。
  let quoteNow = null, quotePending = null
  async function deriveQuote() {
    let rate, asOf
    if (opts.usdRate) {
      const r = await opts.usdRate()
      rate = typeof r?.rate === 'number' ? UP.formatRate(r.rate) : r?.rate
      asOf = r?.asOf ?? now()
    } else {
      const read = await UP.readReferenceRates(needRpc(), tap.rateSources, { maxAgeS: tap.maxQuoteS })
      if (read.reference == null) throw new TapeAPIError('INTERNAL', `no rate source answered (${read.sources.map((s) => `${s.pool}: ${s.reason}`).join('; ')})`)
      rate = UP.formatRate(read.reference)
      asOf = read.block.timestamp
    }
    UP.parseRate(rate)
    if (!Number.isSafeInteger(asOf)) throw new TapeAPIError('INTERNAL', 'usdRate gave no asOf')
    asOf = Math.min(asOf, now())                                   // §4.4: asOf ≤ the envelope's ts / 不晚于信封 ts
    const validUntil = Math.min(asOf + tap.maxQuoteS, now() + quoteValidS)
    if (validUntil <= now()) throw new TapeAPIError('INTERNAL', `the rate is ${now() - asOf} s old, too old for a quote (maxQuoteS ${tap.maxQuoteS})`)
    const q = { rate, asOf, validUntil }
    await quoteStore.put(q, container)                             // honoured from before it is stated / 先登记、后说出
    return q
  }
  async function currentQuote() {
    if (quoteNow && quoteNow.validUntil - now() >= Math.ceil(quoteValidS / 2) && quoteNow.validUntil > now()) return quoteNow
    if (!quotePending) quotePending = deriveQuote().then((q) => { quoteNow = q; return q }).finally(() => { quotePending = null })
    // a rate source that fails while the last quote is still valid: keep stating that one / 来源失败而上一个报价仍有效：继续用它
    try { return await quotePending } catch (e) { if (quoteNow && quoteNow.validUntil > now()) { log('rate source failed; restating the last quote', e?.message); return quoteNow } throw e }
  }
  // §4.4: a rate is honoured while some quote this service stated with exactly that string is within its validUntil.
  async function honoured(rate) { const q = await quoteStore.get(rate, container); return q && q.validUntil >= now() ? q : null }
  const usdOf = (def) => (tap && hasOwn(usdMethods, def.name) ? usdMethods[def.name] : null)
  // What a call costs now, and the hints of §6 (price at the current quote, priceUSD, quote). / 此刻的价格与 §6 的提示
  //   lenient (BAD_VOUCHER, review S5): never derive before the signature checked out (`derive: false` uses only a quote
  //   still valid), and a failed derivation leaves out `quote` with `price` at the cap instead of turning the refusal
  //   into INTERNAL. PAYMENT_REQUIRED is strict: without a quote it cannot be answered (INTERNAL).
  //   宽松（BAD_VOUCHER）：签名验过之前不派生报价，派生失败就不带 `quote`、`price` 按上限，而不把拒绝变成 INTERNAL。
  async function priceHints(def, cap, { lenient = false, derive = true } = {}) {
    const usd = usdOf(def)
    if (!usd) return { price: cap.toString() }
    let quote = null
    if (!lenient) quote = await currentQuote()
    else {
      if (derive) { try { quote = await currentQuote() } catch (e) { log('no quote for a refusal', e?.message) } }
      else if (quoteNow && quoteNow.validUntil > now()) quote = quoteNow
      if (!quote) return { price: cap.toString(), priceUSD: UP.amountObject(UP.parseUsdPrice(usd), 'USD') }
    }
    const { charge, U } = UP.convertUsd({ priceUSD: usd, rate: quote.rate, priceBEM: def.priceBEM })
    return { price: charge.toString(), priceUSD: UP.amountObject(U, 'USD'), quote }
  }

  // 只接受 methods 的自有属性，拒绝原型链上的 constructor/toString 等（L-20 / M-08）/ own properties only
  if (!isPlainObject(methods)) throw new TapeAPIError('INVALID_ARGUMENT', 'methods must be an object')
  for (const m of normalized.methods) {
    if (!METHOD_NAME_RE.test(m.name) || !hasOwn(methods, m.name) || typeof methods[m.name] !== 'function') throw new TapeAPIError('INVALID_ARGUMENT', `no handler for manifest method ${m.name}`)
  }
  const methodDef = (name) => (typeof name === 'string' && METHOD_NAME_RE.test(name) && hasOwn(methods, name)) ? (normalized.methods.find(m => m.name === name) || null) : null

  // ---- 链读带缓存 / cached chain reads ----
  const needRpc = () => { if (!rpc) throw new TapeAPIError('INVALID_ARGUMENT', `rpcUrls not configured: pass createProvider({ rpcUrls: rpcUrlsFor(${chainId}) }) (from @tapeapi/sdk) for the default nodes, or your own`); return rpc }
  async function view(to, name, args) { return decodeReturn(name, await needRpc().ethCall(to, encodeCall(name, args))) }
  // The escrow token check: the escrow's token() must be the token this manifest prices in. A manifest prices in
  // BEM (payment.unit 'BEM'), so the expected token is BEM on BNB Smart Chain (MAINNET.bem) unless opts.escrowToken names
  // another (a local chain); on any other chain there is no default and the check is skipped until escrowToken is given.
  // An escrow of another token would settle every voucher for priceBEM in that token. listen() refuses to start on a
  // mismatch (dev: a warning in the log); from 3.0 every paid call also waits for it, on any path (paidRefusal below).
  // Read once per call, strictly; an unreadable token() is reported, never taken for a match.
  // 托管代币核对：托管的 token() 必须是清单计价的代币。清单以 BEM 计价，BSC 上预期为 BEM，除非 opts.escrowToken 另给（本地链）；其它链没有默认值，
  // 不给 escrowToken 就跳过。不一致时 listen() 拒绝启动（dev 只在日志里警告）；3.0 起每个付费调用也先等它（见下面的 paidRefusal）。读不到绝不当作一致。
  const expectedToken = opts.escrowToken ?? (chainId === 56 ? MAINNET.bem : null)
  async function readEscrowToken() {
    const base = { escrow: hasEscrow ? checksumAddress(escrow) : null, expected: expectedToken ? checksumAddress(expectedToken) : null, token: null }
    const skipped = (why) => ({ ...base, status: 'skipped', message: `escrow token() not checked: ${why}` })
    if (!anyPriced) return skipped('no priced method, nothing is paid')
    if (!hasEscrow) return skipped('no escrow configured')
    if (opts.settlementFacts) return skipped('settlementFacts are configured: the settlement contract is not read')
    if (opts.enforcement) return skipped(`enforcement ${opts.enforcement.name} checks its own channels and token`)
    if (!rpc) return skipped('no rpcUrls')
    if (!expectedToken) return skipped(`chain ${chainId} has no default payment token; pass createProvider({ escrowToken })`)
    let token
    try { token = await view(escrow, 'escrowToken', []) } catch (e) {
      const reverted = e instanceof TapeAPIError && e.code === 'RPC_ERROR' && /execution reverted/i.test(e.message)
      const node = e instanceof TapeAPIError && /^RPC_/.test(e.code) && !reverted
      if (node) return { ...base, status: 'unreadable', message: `token() of escrow ${base.escrow} could not be read (${e.message}): not checked; it is read again at the next check` }
      return { ...base, status: 'no-token', message: `escrow ${base.escrow} answers no token() (${reverted ? 'the call reverts' : 'no address came back'}): not a v3 TapeAPIEscrow, so the token it settles in cannot be checked` }
    }
    token = checksumAddress(token)
    if (!eqAddr(token, expectedToken)) return { ...base, token, status: 'mismatch', message: `escrow ${base.escrow} holds ${token}, but this manifest prices its methods in BEM (${base.expected}): a voucher for priceBEM would settle in another token. Name the escrow that holds ${base.expected}, or pass createProvider({ escrowToken }) on a local chain` }
    return { ...base, token, status: 'ok', message: `escrow ${base.escrow} holds ${token}, the token this manifest prices in` }
  }
  // 3.0: the check guards every paid call, on any path (listen(), handleRequest(), invoke()), not only listen(). A definite
  // answer (ok, skipped, mismatch) is kept for this instance; 'unreadable' and 'no-token' are read again at the next paid
  // call, so a node outage refuses only while it lasts and a failed read is never kept as ok. Concurrent calls share one read.
  // 3.0：每个付费调用都受这项核对约束，任何路径都一样（listen()、handleRequest()、invoke()），不只是 listen()。确定的答案（ok、
  // skipped、mismatch）在本实例内保留；'unreadable' 与 'no-token' 在下一次付费调用时重读：节点故障只在持续期间拒绝，读失败绝不留作 ok。
  // 同时到达的调用共用一次读取。
  let tokenKnown = null, tokenReading = null
  async function readAndKeepEscrowToken() {
    const r = await readEscrowToken()
    if (r.status === 'ok' || r.status === 'skipped' || r.status === 'mismatch') tokenKnown = r
    return r
  }
  // The public provider.checkEscrowToken() (and listen()) return the kept answer once there is one, so an explicit call
  // never replaces it; it reads only while none is kept. / 公开的 checkEscrowToken()（与 listen()）在已有保留的
  // 答案时直接返回它，显式调用不会替换它；只有尚无保留答案时才读取。
  const checkEscrowToken = async () => tokenKnown ?? readAndKeepEscrowToken()
  const escrowTokenNow = () => tokenKnown ?? (tokenReading ??= readAndKeepEscrowToken()
    .catch((e) => ({ status: 'unreadable', escrow: hasEscrow ? checksumAddress(escrow) : null, token: null, expected: expectedToken ? checksumAddress(expectedToken) : null, message: `escrow token() check failed: ${e?.message ?? e}` }))
    .then((r) => { tokenDoubt = r.status !== 'ok' && r.status !== 'skipped'; if (tokenDoubt) log(`${r.message}; paid calls are refused until a check succeeds`); return r })
    .finally(() => { tokenReading = null }))
  // The last check refused: a call with a voucher is then unverified work, paid for out of the free budget.
  // 上一次核对是拒绝：此时带凭证的调用是未经验证的工作，从免费预算里扣。
  let tokenDoubt = false
  const tokenRefusing = () => !devMode && tokenDoubt && tokenKnown?.status !== 'ok' && tokenKnown?.status !== 'skipped'
  const TOKEN_REASON = { mismatch: 'escrow-token-mismatch', 'no-token': 'escrow-no-token', unreadable: 'escrow-token-unreadable' }
  // null: the paid call may go on; otherwise an unsigned 503 to answer (nothing signed, nothing billed). Not in dev, as before.
  // The message is generic (a node error can name a node URL); the details are in the log.
  // null 表示付费调用可以继续；否则返回未签名的 503（不签名、不计费）。dev 下不检查，与以前相同。对外消息不带细节（节点错误可能含节点地址），细节在日志里。
  async function paidRefusal() {
    if (devMode) return null
    const tok = await escrowTokenNow()
    if (tok.status === 'ok' || tok.status === 'skipped') return null
    const message = tok.status === 'mismatch'
      ? `this provider's escrow ${tok.escrow} holds ${tok.token}, not the token its manifest prices in (${tok.expected}): it takes no payment`
      : `this provider could not confirm the token its escrow ${tok.escrow} holds (${tok.status}): it takes no payment until it can`
    return { status: 503, unsigned: { ok: false, error: { code: 'UNSUPPORTED_PAYMENT_TOKEN', message, data: { reason: TOKEN_REASON[tok.status], escrow: tok.escrow, token: tok.token, expected: tok.expected } } }, paid: false, refused: 'escrow-token' }
  }
  const cache = new Map()
  function sweep() { // 过期淘汰，避免随 consumer 数无限增长（M-14）/ evict expired entries so the map cannot grow unbounded
    if (cache.size < cacheMax) return
    const t = Date.now()
    for (const [k, v] of cache) if (v.exp <= t) cache.delete(k)
    if (cache.size >= cacheMax) for (const k of [...cache.keys()].slice(0, cache.size - cacheMax + 1)) cache.delete(k)
  }
  async function cached(key, ttl, fn) {
    const hit = cache.get(key)
    if (hit && hit.exp > Date.now()) return hit.v
    const v = await fn(); sweep(); cache.set(key, { v, exp: Date.now() + ttl }); return v
  }
  let lastBlock = 0
  async function currentBlock() {
    if (!rpc) return 0
    try { lastBlock = await cached('block', blockCacheMs, () => rpc.blockNumber()) } catch (e) { log('block fetch failed', e.message) }
    return lastBlock
  }
  const WITHDRAW_CLOSE_S = BigInt(opts.withdrawCloseS ?? 9 * 86400) // WITHDRAW_COOLDOWN (48h) + WITHDRAW_WINDOW (7d)，见上面的选项说明 / see the options note above
  // 该通道上待执行的提现请求；escrow 无 pendingWithdraw（替代部署）视为无请求 / pending withdraw on this channel; escrows without the view count as none.
  async function pendingWithdrawOf(consumer) {
    try { const [amount, requestedAt] = await view(escrow, 'pendingWithdraw', [consumer, container]); return { amount, requestedAt } }
    catch (e) {
      // A2-04: fail CLOSED. Only a proven "no such function" (the call itself reverted, i.e. an escrow that
      // predates pendingWithdraw) counts as "no request"; a transport / quorum failure must not switch the
      // §3.2(4) `channel − armed` rule off while everything else keeps serving.
      // A2-04：失败即拒绝。只有确证"没有这个函数"（调用本身回滚，即旧版托管）才算"无请求"；
      // 传输或 quorum 失败不能在其它一切照常服务时悄悄关掉 §3.2(4) 的 `channel − armed` 规则。
      if (e instanceof TapeAPIError && e.code === 'RPC_ERROR' && /execution reverted/i.test(e.message)) return { amount: 0n, requestedAt: 0n }
      throw e
    }
  }
  // v2 escrow (TAPI-22 §3.2(4)): the (consumer, this container) channel is the cap -- there is no allowance and no
  // shared balance to reason about. An armed withdraw request is subtracted while it is inside its lifetime
  // [requestedAt, requestedAt + 48h + 7d]: inside the cooldown the provider can still settle ahead of it, but
  // once it is executable the requested amount can leave in the same block as our settle (E-03), so serving
  // against it is extending credit with no cover.
  // v2 托管：(消费者, 本容器) 通道即上限——没有额度、没有共享余额。生命周期内的提现请求从可用额中扣除：
  // 冷静期内提供者仍可抢先结算，但一旦可执行，该金额可在结算同一区块离开（E-03），对其提供服务等于无担保赊账。
  const escrowState = (consumer) => cached(`escrow:${consumer.toLowerCase()}`, escrowCacheMs, async () => {
    // @experimental F2 and F4 from configuration (settlementFacts) / 由配置提供 F2 与 F4
    if (facts) {
      const [claimed, available] = (await Promise.all([facts.amountPaid(consumer), facts.fundsAvailable(consumer)])).map((x) => BigInt(x))
      return { channel: available, claimed, pendingWithdraw: { amount: 0n, requestedAt: 0n }, armed: 0n, available }
    }
    const [channel, claimed, pending] = await Promise.all([
      view(escrow, 'channelOf', [consumer, container]), view(escrow, 'claimedOf', [consumer, container]),
      pendingWithdrawOf(consumer),
    ])
    const armed = pending.amount > 0n && BigInt(now()) <= pending.requestedAt + WITHDRAW_CLOSE_S ? pending.amount : 0n
    const available = channel > armed ? channel - armed : 0n
    return { channel, claimed, pendingWithdraw: pending, armed, available }
  })
  // sessions are per channel: (consumer, this container, key) / 会话按通道：(消费者, 本容器, 密钥)
  const sessionExpiry = (consumer, key) => cached(`sess:${consumer.toLowerCase()}:${key.toLowerCase()}`, sessionCacheMs, async () => (facts ? BigInt(await facts.keyAuthorisedUntil(consumer, key)) : view(escrow, 'sessionExpiry', [consumer, container, key])))

  // 本容器在 escrow 上自设的贡献比例（万分比）。无 RPC 或 RPC 不可用 → null；escrow 无此函数（v0.1 部署）→ 0。
  // This container's opt-in contribution (bps) on the escrow. null when unreadable (no RPC / RPC down); 0 when the
  // escrow predates contributionOf (call reverts).
  async function contribution() {
    if (!rpc) return null
    try { return Number(await cached('contribution', contributionCacheMs, () => view(escrow, 'contributionOf', [container]))) }
    catch (e) {
      if (e instanceof TapeAPIError && (e.code === 'RPC_ERROR' || e.code === 'ABI_INVALID')) return 0
      log('contribution read failed', e.message); return null
    }
  }

  // ---- voucher 校验（按 consumer 串行）/ voucher verification, serialised per consumer ----
  const locks = new Map()
  // consumer|provider -> { cumulative, voucher } held by an in-flight call. The voucher is kept so that when the
  // in-flight figure is the highest, the stale answer can still prove it (D16).
  // 在途调用占用的 { 累计额, 凭证 }；保留凭证，使在途数字最高时过期回答仍能给出证明。
  // consumer|provider -> Set of { cumulative, voucher }: EVERY in-flight call, not only the latest. With one slot a
  // failing later call released the slot of a slower earlier one, and the same cumulative could then be served twice
  // (review M-3). / 每个在途调用都登记，而不只是最新的一个；否则失败的后一个调用会释放较慢的前一个调用的占位。
  const reserved = new Map()
  const heldOf = (key) => { let top = null; for (const r of reserved.get(key) ?? []) if (!top || r.cumulative > top.cumulative) top = r; return top }
  function withLock(key, fn) {
    const prev = locks.get(key) || Promise.resolve()
    const next = prev.then(fn, fn)
    const tail = next.catch(() => {}).then(() => { if (locks.get(key) === tail) locks.delete(key) }) // 链空即清理 / drop idle locks
    locks.set(key, tail)
    return next
  }
  async function verifyVoucher(v, price) {
    // TAPI-22 §3.2: every BAD_VOUCHER carries data.price, so a consumer holding a stale manifest can always tell,
    // whatever else was wrong with the voucher. / 每个 BAD_VOUCHER 都带 data.price，持旧清单的消费者总能察觉。
    const bad = (msg, extra) => { throw new TapeAPIError('BAD_VOUCHER', msg, { ...extra, data: { ...(extra?.data || {}), price: price.toString() } }) }
    if (!isPlainObject(v)) bad('voucher missing')
    if (!isAddress(v.consumer) || !isAddress(v.provider)) bad('voucher.consumer/provider must be addresses')
    if (!eqAddr(v.provider, container)) bad('voucher.provider is not this container')
    if (typeof v.cumulative !== 'string' || !/^\d+$/.test(v.cumulative)) bad('voucher.cumulative must be decimal string')
    // TAPI-22 §3.1: valid while now ≤ expires, the same inclusive boundary the escrow uses / 与托管合约同一个包含边界
    if (!Number.isInteger(v.expires) || v.expires < now()) bad('voucher expired')
    if (v.expires - now() < minVoucherLifeS) bad(`voucher expires in ${v.expires - now()} s; this provider needs at least ${minVoucherLifeS} s to settle`, { data: { minVoucherLifeS } })
    const cumulative = BigInt(v.cumulative)
    let recovered
    // recoverAddress 与合约 ECDSA.recover 一致：高 s / 坏 v 直接拒绝（C-02）/ low-s and v ∈ {27,28} enforced (review C-02)
    if (!hasEscrow) throw new TapeAPIError('INTERNAL', 'this provider has no escrow configured, so it cannot take payment; the operator must set ESCROW')
    try { recovered = recoverAddress(voucherDigest(chainId, escrow, v), v.sig) } catch (e) { bad(`bad voucher signature: ${e.message}`) }
    if (v.signer && !eqAddr(v.signer, recovered)) bad('voucher.signer does not match signature')
    if (!eqAddr(recovered, v.consumer)) {
      // H-01: the session must be live NOW on THIS channel, which is exactly what `settle` checks; it need not
      // outlive the voucher. v2 has no revoke: a key is bounded by one channel and lapses by itself.
      // H-01：会话须在此刻、在**本通道**上有效，与合约 `settle` 判据一致；无需覆盖凭证寿命。v2 没有撤销。
      const exp = BigInt(await sessionExpiry(v.consumer, recovered))
      if (exp < BigInt(now())) bad(`session key ${recovered} not authorised or expired`)
      if (exp - BigInt(now()) < BigInt(minVoucherLifeS)) bad(`session key ${recovered} lapses in ${exp - BigInt(now())} s; this provider needs at least ${minVoucherLifeS} s to settle`, { data: { minVoucherLifeS } })
    }
    const key = `${v.consumer.toLowerCase()}|${container.toLowerCase()}`
    return withLock(v.consumer.toLowerCase(), async () => {
      const { channel, claimed, armed, available } = await escrowState(v.consumer)
      // An in-flight call has already claimed its slice of the meter but is not billed yet; count it so two
      // concurrent calls cannot both spend the same cumulative.
      // 在途调用已占用计量但尚未计费；一并计入，避免两个并发调用花同一个 cumulative。
      // Reservation FIRST, then the store, both after the escrow read: a call commits (store.advance, outside this lock)
      // and only then drops its reservation, so whichever of the two we miss, the other shows it. Reading the store
      // before the escrow read let a call that committed and cleared during that read be missed twice, and the same
      // cumulative was served twice (found 2026-09-29 when batched RPC reads made the escrow read yield longer).
      // 先读在途预留、再读 store，且都在读托管之后：调用先提交（store.advance，在锁外）再撤预留，所以两者至少能看到一个。
      // 以前在读托管之前读 store，读托管期间提交并撤预留的调用两边都看不到，同一个 cumulative 被服务两次
      // （2026-09-29 发现：批量 RPC 让读托管的让出时间变长）。
      const inflight = heldOf(key)
      const prev = await store.get(v.consumer, container)
      // E-05: the store may lag the chain (restart, new instance); a voucher at or below claimedOf can never settle.
      // E-05：本地 store 可能落后于链上（重启、扩容）；不高于 claimedOf 的凭证永远无法结算。
      const stored = prev ? BigInt(prev.cumulative) : 0n
      const held = inflight?.cumulative ?? 0n
      let last = stored > claimed ? stored : claimed
      if (held > last) last = held
      // 过期累计：把 lastCumulative 连同**消费者自己签过的那张凭证**一起放进已签名的错误负载。
      // 光给数字是不够的：客户端无法分辨真相与谎言，恶意提供者报一个天文数字就能让对方签出一张
      // 榨干额度的凭证。附上原凭证后，客户端可以用自己的签名验证这个数字确实是它许诺过的。
      // 链上已结算的部分（claimed）无需证据——任何人都能自行读链核对。
      // The stale-cumulative error carries the number AND the consumer's own signed voucher for it.
      // The number alone is not enough: a client cannot tell truth from a lie, and a hostile provider
      // that reports an enormous value would make the client sign a voucher draining its allowance.
      // With the voucher attached the client verifies its own signature over that figure. The
      // on-chain part (claimed) needs no proof: anyone can read it.
      // Whichever figure won -- the stored meter or an in-flight reservation -- is proven by the consumer's voucher
      // for exactly that figure, so a second payer instance racing an in-flight call can still resync (D16).
      // 无论胜出的是已存计量还是在途预留，都用消费者对恰好该数字签的凭证来证明，使与在途调用竞争的第二个付款实例也能重新同步。
      const proof = inflight && held === last && held > claimed ? inflight.voucher
        : prev && BigInt(prev.cumulative) === last ? { cumulative: prev.cumulative, expires: prev.expires, sig: prev.sig }
        : undefined
      // `price` lets a consumer tell a stale PRICE from a stale COUNTER. Without it the two are
      // indistinguishable, and a consumer holding a manifest from before a price rise retries at the old price
      // for ever. The client treats this number as a hint and re-reads the manifest from the chain; it is never
      // authority, so naming a huge price here buys a provider nothing.
      // `price` 让消费者能区分"价格旧了"和"计数器旧了"。没有它两者无法分辨，持有涨价前清单的消费者会一直
      // 按旧价重试。客户端只把这个数字当提示，随后从链上重读清单；它不是权威，所以在这里报一个天价毫无用处。
      const stale = { data: { lastCumulative: last.toString(), onChainClaimed: claimed.toString(), price: price.toString(), ...(proof ? { voucher: proof } : {}) } }
      if (cumulative <= claimed) bad(`cumulative ${cumulative} already settled on-chain (claimed ${claimed})`, stale)
      if (cumulative < last + price) bad(`cumulative ${cumulative} < last ${last} + price ${price}`, stale)
      // TAPI-22 §3.2(4): cumulative − claimedOf ≤ channelOf − armed. / 累计额 − 已结算 ≤ 通道余额 − 已上膛的提现。
      if (cumulative - claimed > available) bad(`unsettled ${cumulative - claimed} exceeds the available channel ${available} (channel ${channel}, armed withdraw ${armed})`)
      // Reserve now, bill later: the meter only advances once the method has actually produced a result.
      // Otherwise an upstream 502 would be charged to the consumer.
      // 先预留、后计费：方法真正产出结果后才推进计量；否则上游 502 也会被扣费。
      const mine = { cumulative, voucher: { cumulative: cumulative.toString(), expires: v.expires, sig: v.sig } }
      if (!reserved.has(key)) reserved.set(key, new Set())
      reserved.get(key).add(mine)
      const record = { consumer: checksumAddress(v.consumer), provider: container, cumulative: cumulative.toString(), expires: v.expires, sig: v.sig, signer: recovered, updatedAt: now() }
      const clear = () => { const s = reserved.get(key); if (s) { s.delete(mine); if (!s.size) reserved.delete(key) } }
      return {
        consumer: checksumAddress(v.consumer), signer: recovered, cumulative,
        // 处理方法在锁外执行，两个并发调用可能乱序完成；写回必须重新拿锁并且只许单调上升，
        // 否则慢的小额凭证会覆盖掉快的大额凭证，provider 少收钱（H-06）。
        // Handlers run outside the lock, so two concurrent calls can finish out of order: the write-back retakes the
        // lock and is monotonic, otherwise a slow low-cumulative call overwrites a fast high-cumulative record and
        // the provider silently loses the difference (review H-06).
        commit: async () => {
          try {
            if (typeof store.advance === 'function') {
              await store.advance(v.consumer, container, record)   // one atomic statement; no lock needed / 单条原子语句，无需加锁
            } else {
              await withLock(v.consumer.toLowerCase(), async () => {
                const cur = await store.get(v.consumer, container)
                if (!cur || BigInt(cur.cumulative) < cumulative) await store.set(v.consumer, container, record)
              })
            }
          } finally { clear() }
        },
        release: clear,
      }
    })
  }

  // @experimental (phase 1) The payment acceptance: the enforcement backend whose vouchers this provider takes. Without
  // opts.enforcement it is the TAPI-22 escrow channel above, unchanged. / 本服务接受哪种执行后端的凭证；不给即上面的托管通道，不变
  const acceptance = opts.enforcement ?? { name: 'escrow-channel', verifyVoucher }

  // ---- @experimental voucher checks of the TAP draft §5.2, for a service with `usdPricing` ----
  // The 1.8.1 verifyVoucher above stays as it is for every other manifest. Same serialisation, reservations, store and
  // reconciliation with the amount paid; in addition: the checks run in the draft's order and each refusal names its
  // `reason`; v must be 27 or 28; a USD-priced method needs a `rate` this service has quoted and still honours, and costs
  // its conversion at that rate (capped by priceBEM). Returns the lease with `last` and the charge of this call.
  // 上面 1.8.1 的 verifyVoucher 对其它清单保持原样。串行、预留、store 与对账都相同；此外：按草稿的顺序检查，每个拒绝写明
  // `reason`；v 只能是 27/28；USD 计价方法需要本服务报过且仍兑现的 `rate`，按该汇率换算（以 priceBEM 封顶）计费。
  async function verifyVoucherTap(v, def, cap) {
    const usd = usdOf(def)
    let signed = false   // hints derive a quote only once the signature checked out (review S5) / 验签之后才派生报价
    const bad = async (reason, msg, extra) => { throw new TapeAPIError('BAD_VOUCHER', msg, { data: { reason, ...(await priceHints(def, cap, { lenient: true, derive: signed })), ...(extra || {}) } }) }
    const wire = UP.voucherWireProblem(v)
    if (wire) await bad('malformed', `malformed voucher: ${wire}`)
    if (!eqAddr(v.provider, container)) await bad('provider', 'voucher.provider is not this container')
    if (v.expires < now()) await bad('expired', 'voucher expired')
    if (v.expires - now() < minVoucherLifeS) await bad('lifetime', `voucher expires in ${v.expires - now()} s; this provider needs at least ${minVoucherLifeS} s to settle`, { minVoucherLifeS })
    if (!hasEscrow) throw new TapeAPIError('INTERNAL', 'this provider has no escrow configured, so it cannot take payment; the operator must set ESCROW')
    let recovered
    try { recovered = recoverVoucherSigner(chainId, escrow, v, v.sig) } catch (e) { await bad('signature', `bad voucher signature: ${e.message}`) }
    if (v.signer && !eqAddr(v.signer, recovered)) await bad('signature', 'voucher.signer does not match signature')
    signed = true
    if (!eqAddr(recovered, v.consumer)) {
      const exp = BigInt(await sessionExpiry(v.consumer, recovered))   // F3
      if (exp < BigInt(now())) await bad('signature', `key ${recovered} is not authorised for this channel, or its authorisation expired`)
      if (exp - BigInt(now()) < BigInt(minVoucherLifeS)) await bad('lifetime', `key ${recovered} lapses in ${exp - BigInt(now())} s; this provider needs at least ${minVoucherLifeS} s to settle`, { minVoucherLifeS })
    }
    let charge = cap, quoted = null, capped = false
    if (usd) {
      if (typeof v.rate !== 'string') await bad('rate', 'a USD-priced method needs voucher.rate, the rate of a quote of this provider')
      quoted = UP.RATE_RE.test(v.rate) ? await honoured(v.rate) : null
      if (!quoted) await bad('rate', `rate ${String(v.rate).slice(0, 40)} is not a quote of this provider that is still valid`)
      ;({ charge, capped } = UP.convertUsd({ priceUSD: usd, rate: v.rate, priceBEM: def.priceBEM }))
    }
    const cumulative = BigInt(v.cumulative)
    const key = `${v.consumer.toLowerCase()}|${container.toLowerCase()}`
    // the lock is taken only to read and reserve; a refusal's hints are computed after it is released
    // 锁只用于读取与预留；拒绝的提示在释放锁之后才计算
    const verdict = await withLock(v.consumer.toLowerCase(), async () => {
      const { channel, claimed, armed, available } = await escrowState(v.consumer)   // F2, F4
      const inflight = heldOf(key)
      const prev = await store.get(v.consumer, container)
      const stored = prev ? BigInt(prev.cumulative) : 0n
      const held = inflight?.cumulative ?? 0n
      let last = stored > claimed ? stored : claimed
      if (held > last) last = held
      const proof = inflight && held === last && held > claimed ? inflight.voucher
        : prev && BigInt(prev.cumulative) === last ? { cumulative: prev.cumulative, expires: prev.expires, sig: prev.sig }
        : undefined
      const stale = { lastCumulative: last.toString(), onChainClaimed: claimed.toString(), ...(proof ? { voucher: proof } : {}) }
      if (cumulative <= last) return { refuse: ['stale', `cumulative ${cumulative} is not above the last accepted ${last}`, stale] }
      // `insufficient` carries the same proof as `stale`: a client whose `last` is behind cannot resync without it
      // `insufficient` 与 `stale` 带同样的证明：`last` 落后的客户端没有它无法重新同步
      if (cumulative - last < charge) return { refuse: ['insufficient', `cumulative ${cumulative} − last ${last} is below the charge ${charge}`, stale] }
      if (cumulative - claimed > available) return { refuse: ['funds', `unsettled ${cumulative - claimed} exceeds the funds held for the channel ${available} (channel ${channel}, armed withdraw ${armed})`] }
      const mine = { cumulative, voucher: { cumulative: cumulative.toString(), expires: v.expires, sig: v.sig } }
      if (!reserved.has(key)) reserved.set(key, new Set())
      reserved.get(key).add(mine)
      return { last, mine }
    })
    if (verdict.refuse) await bad(...verdict.refuse)
    const { last, mine } = verdict
    const record = { consumer: checksumAddress(v.consumer), provider: container, cumulative: cumulative.toString(), expires: v.expires, sig: v.sig, signer: recovered, updatedAt: now(), ...(usd ? { rate: v.rate } : {}) }
    const clear = () => { const s = reserved.get(key); if (s) { s.delete(mine); if (!s.size) reserved.delete(key) } }
    return {
      consumer: checksumAddress(v.consumer), signer: recovered, cumulative, last,
      usd: usd ? { priceUSD: usd, rate: v.rate, rateAsOf: quoted.asOf, capped } : null,
      commit: async () => {
        try {
          if (typeof store.advance === 'function') await store.advance(v.consumer, container, record)
          else await withLock(v.consumer.toLowerCase(), async () => { const cur = await store.get(v.consumer, container); if (!cur || BigInt(cur.cumulative) < cumulative) await store.set(v.consumer, container, record) })
        } finally { clear() }
      },
      release: clear,
    }
  }

  // ---- 信封 / envelopes (TAPI-21 v2: digest covers {method, params} and ok) ----
  // TOOLS_CHANGED: an MCP-bound service whose upstream tools no longer match the manifest's toolsSha256 (TAPI-20 §3.8).
  // TOOLS_CHANGED：上游工具与清单 toolsSha256 不再相符的 MCP 绑定服务（TAPI-20 §3.8）。
  const STATUS = { PAYMENT_REQUIRED: 402, BAD_VOUCHER: 402, METHOD_NOT_FOUND: 404, BAD_REQUEST: 400, INTERNAL: 500, TOOLS_CHANGED: 409 }
  function envelope({ id, method, params }, ok, payload, block) {
    const ts = now()
    const env = ok ? { id, ok: true, result: payload } : { id, ok: false, error: payload }
    Object.assign(env, { container, ts, block })
    env.sig = signResponse({ container, id, method, params, ok, body: payload, ts }, signerKey)
    return env
  }
  function send(res, status, obj) {
    const body = JSON.stringify(obj)
    res.writeHead(status, { 'content-type': 'application/json', 'content-length': Buffer.byteLength(body), ...CORS })
    res.end(body)
  }
  const CORS = { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,POST,OPTIONS', 'access-control-allow-headers': 'content-type,accept', 'access-control-max-age': '86400' }

  // 对外错误：INTERNAL 一律泛化，细节只进日志（M-13）/ outward errors: INTERNAL is always generic, details go to log
  function errorPayload(e) {
    const known = (c) => typeof c === 'string' && hasOwn(STATUS, c)
    const code = known(e?.code) ? e.code : 'INTERNAL'
    if (code === 'INTERNAL') {
      log('internal error', e)
      // A handler may attach the revert bytes of a call it made (TAPI-23 §3.3): that is chain state anyone can
      // reproduce, not an upstream detail, so it is the one thing an INTERNAL may carry. Nothing else passes.
      // 处理器可附上它所做调用的 revert 字节（TAPI-23 §3.3）：那是人人可复现的链上状态，不是上游细节，是 INTERNAL 唯一可携带的内容。
      const revert = e instanceof TapeAPIError ? e.data?.revert : undefined
      if (typeof revert === 'string' && revert.length <= 2 + 2 * 4096 && /^0x(?:[0-9a-fA-F]{2})*$/.test(revert)) return { code, message: 'execution reverted', data: { revert: revert.toLowerCase() } }
      return { code, message: 'internal error' }
    }
    const out = { code, message: e.message || code }
    if (isPlainObject(e.data)) out.data = e.data
    return out
  }

  const utf8Length = (str) => new TextEncoder().encode(str).length

  // TAPI-21 §3.2: what an answer to a parsed request object is signed over. An invalid `id` (missing, not a string,
  // empty, over 128 UTF-16 units) is not trusted, and neither are the params beside it: ("", {}). Params with no
  // canonical form: (id, {}). Otherwise the request's own (id, params). One helper for the normal path and the crash
  // path, so a spec-conformant client verifies every answer (spec review SD-1).
  // TAPI-21 §3.2：对已解析请求对象的回答签在什么之上。无效 `id`（缺失、非字符串、空、超过 128 个 UTF-16 单元）不可信，
  // 它旁边的 params 也不可信：("", {})。没有规范形式的 params：(id, {})。否则就是请求自己的 (id, params)。
  // 正常路径与崩溃路径共用一个函数，使按规范实现的客户端能验证每一个回答。
  // An id with a lone UTF-16 surrogate has no canonical form (canon.js): every envelope binding it would fail to sign or
  // to verify, so it binds as no id at all (FIXED ID-LS). / 含孤立代理项的 id 没有规范形式，按没有 id 处理。
  function bindingOf(body, method) {
    let id = typeof body?.id === 'string' && body.id.length >= 1 && body.id.length <= 128 ? body.id : ''
    if (id) { try { canonicalJSON(id) } catch { id = '' } }
    let params = id && isPlainObject(body?.params) ? body.params : {}
    let paramsError = null
    try { canonicalJSON({ method, params }) } catch (e) { paramsError = e; params = {} }
    return { req: { id, method, params }, paramsError }
  }

  // @experimental ctx.resend(env): only an ok envelope this provider signed over this very request (id, method, params),
  // and never on a call that carries a voucher lease. Anything else is INTERNAL (generic outward).
  // 只重发本服务对同一请求签过的成功信封，且不用于带凭证的调用；否则 INTERNAL。
  function resendable(env, { id, method, params }, lease) {
    const bad = (why) => new TapeAPIError('INTERNAL', `ctx.resend: ${why}`)   // invoke()'s catch releases any lease / 由 invoke 的 catch 释放租约
    if (lease) throw bad('a priced call is never answered with a saved envelope')
    if (!isPlainObject(env) || env.ok !== true || env.id !== id || !eqAddr(env.container, container) || !Number.isInteger(env.ts) || typeof env.sig !== 'string') throw bad('not an ok envelope of this provider for this id')
    let who = null
    try { who = recoverResponseSigner({ container, id, method, params, ok: true, body: env.result, ts: env.ts }, env.sig) } catch { /* below */ }
    if (!who || !eqAddr(who, signerAddr)) throw bad('the envelope is not this provider\'s signature over this request')
    return env
  }
  function deepFreeze(v) { if (v && typeof v === 'object') { for (const x of Object.values(v)) deepFreeze(x); Object.freeze(v) } return v }

  // @experimental see ctx.request in invoke() / 见 invoke() 里的 ctx.request
  function requestView(body) {
    const rest = {}
    for (const [k, v] of Object.entries(isPlainObject(body) ? body : {})) if (k !== 'method' && k !== 'params') rest[k] = v
    const freeze = (v) => { if (v && typeof v === 'object') { for (const x of Object.values(v)) freeze(x); Object.freeze(v) } return v }
    return freeze(JSON.parse(JSON.stringify(rest)))
  }

  // 执行一次调用（不含 HTTP）/ Execute one call (transport-agnostic).
  // `ip` is the caller identity the HTTP layer vouches for. A return of { rateLimited: seconds } means "answer with an
  // unsigned 429", never an envelope. / `ip` 由 HTTP 层给出；返回 { rateLimited } 表示回未签名的 429，而不是信封。
  // A return of { status, unsigned } (the delegation lapsed, arch A3) means "answer `unsigned` as it is, unsigned".
  // 返回 { status, unsigned }（委托已过期）表示原样回 `unsigned`，不签名。
  async function invoke(body, { ip = 'unknown', sentMethod } = {}) {
    if (delegationLapsed()) return { status: 503, unsigned: lapsedError(), paid: false }   // arch A3
    const method = typeof body?.method === 'string' ? body.method : ''
    // A request whose params have no canonical form cannot be answered with an envelope bound to them. Check it
    // BEFORE any handler runs, and bind the refusal to empty params (runtime audit F-07). An invalid id binds to
    // ("", {}) (TAPI-21 §3.2, SD-1). / 参数没有规范形式的请求，无法用绑定这些参数的信封作答。在任何处理器运行之前
    // 检查，拒绝时绑定空参数。无效 id 绑定 ("", {})。
    const { req, paramsError } = bindingOf(body, method)
    const { id, params } = req
    const block = await currentBlock()
    let lease = null
    let verified = false
    // Unverified work -- a malformed request, an unknown method, a free method, a paid method without a valid
    // voucher -- is paid for out of the IP's free budget. Only a voucher that verifies moves a call to the paid
    // budget (runtime audit F-01). / 未经验证的工作都从该 IP 的免费预算里扣；只有验过的凭证才让调用改走付费预算。
    const spendFree = () => (rl ? rateLimited(`free:${ip}`, rl.free) : 0)
    try {
      if (!id) { const w = spendFree(); if (w) return { rateLimited: w }; throw new TapeAPIError('BAD_REQUEST', 'id (string, 1..128 chars, well-formed Unicode) required') }
      if (paramsError) { const w = spendFree(); if (w) return { rateLimited: w }; throw new TapeAPIError('BAD_REQUEST', `params have no canonical form: ${paramsError.message}`) }
      // TAPI-21 §3.1: a body `method` that disagrees with the path is refused, never silently overwritten (D14)
      // 与路径不一致的 body `method` 被拒绝，而不是被悄悄覆盖
      if (sentMethod !== undefined && sentMethod !== method) { const w = spendFree(); if (w) return { rateLimited: w }; throw new TapeAPIError('BAD_REQUEST', 'body method does not match the path') }
      if (body.params != null && !isPlainObject(body.params)) { const w = spendFree(); if (w) return { rateLimited: w }; throw new TapeAPIError('BAD_REQUEST', 'params must be a JSON object') }
      const def = methodDef(method)
      // validateManifest 已经用同一个解析器校验过每个 priceBEM，这里不会再抛 / already validated above
      const price = def ? parseUnits(def.priceBEM || '0', BEM_DECIMALS) : 0n
      if (price === 0n) { const w = spendFree(); if (w) return { rateLimited: w } }
      if (!def) throw new TapeAPIError('METHOD_NOT_FOUND', `unknown method ${method.slice(0, 64)}`)
      // @experimental ctx.request: a frozen JSON copy of the request's top-level members other than
      // `method` and `params` (its `id`, a `voucher` if sent, and any member TAP-13 does not define, such as `grant`), for
      // the experimental package @tapeapi/interop. Read-only for the handler; nothing the provider signs or bills changes.
      // ctx.request：请求顶层成员（method、params 之外）的冻结 JSON 副本，供 @tapeapi/interop 使用；签名与计费不变。
      const ctx = { consumer: null, block, manifest, method: def, price, clientIp: ip, request: requestView(body) }
      // @experimental for @tapeapi/interop (a lost answer retried with the same id): ctx.onSigned(fn) is told the
      // signed envelope of THIS call (a frozen JSON copy) once it has passed every check and is about to be sent;
      // ctx.resend(env) answers with an envelope this provider signed earlier for this very request (same id, method,
      // params), byte for byte: not signed again, not billed again, and only on a free call.
      // ctx.onSigned(fn)：本次调用的已签信封各项检查都成功、即将发出时告知（冻结副本）；ctx.resend(env)：原样重发本服务此前对同一请求
      // （同 id、method、params）签过的信封，不重签、不再计费，只用于免费调用。
      const signedHooks = []
      ctx.onSigned = (fn) => { if (typeof fn === 'function') signedHooks.push(fn) }
      ctx.resend = (env) => ({ [RESEND]: env })
      if (price > 0n) {
        // An IP that has spent its free budget AND keeps presenting vouchers that fail is refused before the costly
        // part (signature recovery, uncached chain reads). A paying consumer whose vouchers verify is never affected.
        // 既耗尽了免费预算、又不断提交验不过的凭证的 IP，在昂贵的部分之前就被拒绝；凭证能验过的付费消费者从不受影响。
        if (rl && overBudget(`fail:${ip}`, FAIL_BUDGET) && overBudget(`free:${ip}`, rl.free)) return { rateLimited: retryAfter(`fail:${ip}`) }
        if (!body.voucher) {
          const w = tap ? (rl ? rateLimited(`quote:${ip}`, rl.quote) : 0) : spendFree(); if (w) return { rateLimited: w }
          // 3.0: no price is offered while the escrow's token is not confirmed / 托管代币未确认时不报价
          const refused = await paidRefusal(); if (refused) return refused
          if (!tap) throw new TapeAPIError('PAYMENT_REQUIRED', `${def.name} costs ${def.priceBEM} BEM per call`, { data: { price: price.toString() } })
          // @experimental draft §6: price (at the current quote), priceUSD and quote, and minVoucherLifeS when this provider has one
          const usd = usdOf(def)
          throw new TapeAPIError('PAYMENT_REQUIRED', usd ? `${def.name} costs ${usd} USD per call, at most ${def.priceBEM} BEM` : `${def.name} costs ${def.priceBEM} BEM per call`, { data: { ...(await priceHints(def, price)), ...(minVoucherLifeS > 0 ? { minVoucherLifeS } : {}) } })
        }
        // A call with a voucher refused for the escrow token is unverified work like any other (TAPI-21 §3.4): it spends the
        // free budget, and once that is spent no further token() read is made for it. The first paid call of
        // an instance is never held back by it. / 因托管代币被拒的带凭证调用同样是未经验证的工作：扣免费预算，预算用完后不再为它读 token()。
        // 实例的第一个付费调用不受此影响。
        if (rl && tokenRefusing() && overBudget(`free:${ip}`, rl.free)) return { rateLimited: retryAfter(`free:${ip}`) }
        const refused = await paidRefusal()   // 3.0, before any voucher is checked / 在验凭证之前
        if (refused) { const w = spendFree(); return w ? { rateLimited: w } : refused }
        try { lease = tap ? await verifyVoucherTap(body.voucher, def, price) : await acceptance.verifyVoucher(body.voucher, price) }
        catch (e) { if (rl) { rateLimited(`fail:${ip}`, Infinity); rateLimited(`free:${ip}`, Infinity) } throw e }
        verified = true
        ctx.consumer = lease.consumer; ctx.voucherSigner = lease.signer; ctx.cumulative = lease.cumulative
        if (tap) ctx.charge = lease.cumulative - lease.last   // @experimental the charge of this call (draft §5.3) / 本次收费
        // Keyed on the consumer the voucher signature PROVED, never on the `consumer` field as sent: an unverified
        // field would let anyone exhaust a victim's budget by writing the victim's address into junk vouchers.
        // 按凭证签名已证明的消费者计，绝不按请求里原样的 `consumer` 字段。
        if (rl && rl.paid) {
          const wait = rateLimited(`paid:${String(lease.consumer).toLowerCase()}`, rl.paid)
          if (wait) { lease.release(); lease = null; return { rateLimited: wait } }
        }
      }
      let timer
      const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(new TapeAPIError('INTERNAL', `handler ${def.name} exceeded ${handlerTimeoutMs} ms`)), handlerTimeoutMs) })
      let result
      try { result = await Promise.race([methods[def.name](params, ctx), timeout]) } finally { clearTimeout(timer) }
      // Lapsed while the handler ran: sign nothing and bill nothing (arch A3) / 处理期间过期：不签名、不计费
      if (delegationLapsed()) { if (lease) lease.release(); return { status: 503, unsigned: lapsedError(), paid: false } }
      if (result !== null && typeof result === 'object' && hasOwn(result, RESEND)) return { status: 200, env: resendable(result[RESEND], req, lease), paid: false }
      // @experimental draft §5.3 / §7: a priced result is an object and carries the charge record; a method that returns
      // anything else, or uses the member `charge` itself, is answered INTERNAL and charges nothing.
      // 计价结果是对象并带计费记录；返回别的、或自己用了 `charge` 成员的方法答 INTERNAL，不收费。
      if (tap && lease) {
        if (!isPlainObject(result)) throw new TapeAPIError('INTERNAL', `priced method ${def.name} must return a JSON object: it carries the charge record`)
        if (hasOwn(result, 'charge')) throw new TapeAPIError('INTERNAL', `priced method ${def.name} uses the result member "charge", which the charge record reserves`)
        result = { ...result, charge: UP.chargeRecord({ consumer: lease.consumer, cumulative: lease.cumulative, amount: lease.cumulative - lease.last, usd: lease.usd, quote: lease.usd ? await currentQuote() : undefined }) }
      }
      // Sign FIRST, bill second: a result that cannot be signed (no canonical form) must not be charged for
      // (runtime audit F-06). / 先签名、后计费：签不了名的结果不能收钱。
      const env = envelope(req, true, result ?? null, block)
      // Nor is a result too large to send (TAPI-21 §3.2, 1 MiB) / 超过 1 MiB 发不出去的结果也不收钱
      if (utf8Length(JSON.stringify(env)) > RESPONSE_LIMIT) throw new TapeAPIError('INTERNAL', `response of ${def.name} exceeds ${RESPONSE_LIMIT} bytes`)
      if (lease) await lease.commit()   // bill only for a delivered result / 交付了结果才计费
      if (signedHooks.length) {
        const copy = deepFreeze(JSON.parse(JSON.stringify(env)))
        for (const fn of signedHooks) { try { await fn(copy) } catch (e) { log('ctx.onSigned hook failed (the answer is sent anyway)', e) } }
      }
      return { status: 200, env, paid: verified }
    } catch (e) {
      if (lease) lease.release()        // the caller is not charged for a failed call / 失败的调用不计费
      const payload = errorPayload(e)
      return { status: STATUS[payload.code], env: envelope(req, false, payload, block), paid: false }
    }
  }

  // ---- node:http entry point: a thin adapter over handleRequest() (arch B17) ----
  // Routing, limiter, health and error mapping live ONCE, in handleRequest(); this only converts an IncomingMessage
  // into a Request and the Response back. Two copies had drifted before: the delegation-expiry fix (arch A3) had to
  // land in both.
  // ---- node:http 入口：handleRequest() 之上的薄适配层（arch B17）----
  // 路由、限流、health 与错误映射只在 handleRequest() 里写一次；这里只把 IncomingMessage 转成 Request、再把 Response 写回。
  // 两份实现曾经不同步过：委托过期的修复（arch A3）得两处都改。
  // The Fetch spec refuses these in a Request. Any method other than GET / POST / OPTIONS gets the same 404 / 405, so a
  // stand-in keeps the answer. / Fetch 规范不允许 Request 用这几个方法；GET / POST / OPTIONS 以外的方法答案都一样，换一个即可。
  const FETCH_FORBIDDEN = new Set(['CONNECT', 'TRACE', 'TRACK'])
  // Exported as it is, so it never rejects: whoever wires http.createServer(p.handler) gets an answer, not an unhandled
  // rejection (review R2-5). / 原样导出，因此绝不 reject：直接用 http.createServer(p.handler) 的人得到回答，而不是未处理的拒绝。
  function handler(req, res) {
    return nodeRequest(req, res).catch((e) => {
      // A logger or a response that throws here must not turn into a rejection either (review R3-6).
      // 这里的日志或响应本身抛错，也不能变成拒绝。
      try { log('handler crash', e) } catch { /* the logger is broken; the answer still goes out / 日志坏了，回答照发 */ }
      try { if (!res.headersSent) send(res, 500, { ok: false, error: { code: 'INTERNAL', message: 'internal error' } }); else res.destroy() }
      catch { try { res.destroy() } catch { /* nothing left to do / 已无可做 */ } }
    })
  }
  async function nodeRequest(req, res) {
    let url
    try { url = new URL(req.url, 'http://localhost') }
    catch { return send(res, 400, { ok: false, error: { code: 'BAD_REQUEST', message: 'unparsable request target' } }) }   // e.g. port 99999 (review R3-6)
    // An absolute-form target may carry user:pass@, which a fetch Request refuses to hold; nothing here uses it
    // (review R2-5). / 绝对形式的请求目标可能带 user:pass@，fetch 的 Request 不接受；这里也用不到它。
    url.username = ''; url.password = ''
    // Identity as it always was here: the configured proxy header's last hop, else the socket peer -- never a header
    // nobody configured (runtime audit F-03 / F-04). Handed over as clientIp, so handleRequest reads no header itself.
    // 身份与以往一致：配置过的代理头的最后一跳，否则是 socket 对端；绝不用未配置的头。作为 clientIp 交给 handleRequest。
    const ip = (clientIpHeader && headerIp(req.headers[clientIpHeader])) || req.socket?.remoteAddress || 'unknown'
    const method = FETCH_FORBIDDEN.has(req.method) ? 'PUT' : req.method
    const headers = new Headers()
    for (let i = 0; i + 1 < req.rawHeaders.length; i += 2) { try { headers.append(req.rawHeaders[i], req.rawHeaders[i + 1]) } catch { /* not a fetch header */ } }
    // Pulled only when handleRequest reads it (highWaterMark 0), so a request refused before the body -- 404, 405,
    // 429, 503 -- reads none of it, as before. The byte count and both caps are readRequestText's; cancelling at the
    // hard cap destroys the socket, and a client abort surfaces as a read error ("malformed request").
    // 只有 handleRequest 读取时才拉取（highWaterMark 0），在读 body 之前就被拒的请求一个字节也不读。字节计数与两道上限都在
    // readRequestText 里；超过硬上限时取消即销毁 socket，客户端中途断开表现为读取错误。
    let chunks = null
    const body = method === 'GET' || method === 'HEAD' ? null : new ReadableStream({
      async pull(c) {
        chunks ??= req[Symbol.asyncIterator]()
        const { done, value } = await chunks.next()
        if (done) c.close(); else c.enqueue(value)
      },
      cancel() { req.destroy() },
    }, { highWaterMark: 0 })
    const r = await handleRequest(new Request(url, { method, headers, body, duplex: 'half' }), { clientIp: ip })
    const out = Buffer.from(await r.arrayBuffer())
    const head = Object.fromEntries(r.headers)
    if (r.status !== 204) head['content-length'] = String(out.length)
    // Written even if the socket is gone (a hard-cap cut-off): Node drops it, and the promise still settles.
    // socket 已断开（硬上限截断）时照样写：Node 会丢弃，promise 照常了结。
    res.writeHead(r.status, head)
    res.end(out)
  }

  // Fixed window, bounded map. Not distributed: two processes each get their own budget, which is stated in
  // TAPI-21 §3.4 rather than papered over. / 固定窗口、有界表。不跨进程共享：两个进程各有一份预算，这一点写进规范而不是假装没有。
  const buckets = new Map()
  function rateLimited(key, budget) {
    if (!rl || !budget) return 0
    const nowMs = Date.now()
    let b = buckets.get(key)
    if (!b || nowMs >= b.reset) { b = { n: 0, reset: nowMs + rl.windowMs }; buckets.set(key, b) }
    b.n++
    // Hard bound: drop the oldest buckets (Map keeps insertion order), expired or not. Losing an old bucket only
    // forgets its count; an unbounded map is a memory leak under many distinct IPs (runtime audit F-02).
    // 硬上限：丢掉最早的桶（Map 保持插入顺序），无论是否过期。丢一个旧桶只是忘掉它的计数；无界的表在大量不同 IP 下就是内存泄漏。
    while (buckets.size > rl.max) buckets.delete(buckets.keys().next().value)
    return b.n > budget ? Math.max(1, Math.ceil((b.reset - nowMs) / 1000)) : 0
  }
  const overBudget = (key, budget) => { const b = buckets.get(key); return !!b && Date.now() < b.reset && b.n >= budget }
  const retryAfter = (key) => { const b = buckets.get(key); return b ? Math.max(1, Math.ceil((b.reset - Date.now()) / 1000)) : 1 }
  const stats = { singleInstance, started: Math.floor(Date.now() / 1000), calls: 0, ok: 0, failed: 0, free: 0, paid: 0, rateLimited: 0, delegationLapsed: 0, escrowTokenRefused: 0, byMethod: Object.create(null), byCode: Object.create(null) }
  // health 只暴露 signer、版本与服务参数；委托过期后 ok 为 false（arch A3）/ signer, version and serving parameters; ok is false once the delegation lapsed
  const health = () => ({ ok: !delegationLapsed(), signer: signerAddr, version: VERSION, minVoucherLifeS, delegationExpires: delegationExpires(), rateLimit: rl ? { windowMs: rl.windowMs, free: rl.free, paid: rl.paid, ip: rl.ip } : null })
  const bump = (o, k) => { o[k] = (o[k] || 0) + 1 }

  // ---- Fetch-API entry point: Cloudflare Workers, Deno, Bun, or a Node http server you wire up yourself ----
  // The one implementation of routing and the limiter (handler() adapts node:http onto it), with no node: dependency.
  // The caller supplies the client identity, because there is no socket here: on Workers that is
  // request.headers.get('cf-connecting-ip'), which the edge sets and a client cannot forge.
  // ---- Fetch API 入口：Cloudflare Workers、Deno、Bun，或你自己接的 Node 服务器 ----
  // 路由与限流的唯一实现（handler() 把 node:http 适配到这里），不依赖任何 node: 模块。
  // 客户端身份由调用方给出，因为这里没有 socket：在 Workers 上就是 cf-connecting-ip，由边缘设置、客户端伪造不了。
  // Byte-counted and hard-capped: `request.text()` measures UTF-16 units and buffers everything first, so a large
  // body was read in full before the limit was even checked (runtime audit F-05).
  // 按字节计数并设硬上限：`request.text()` 数的是 UTF-16 单元，而且会先把全部内容读进来，大请求体会在检查上限之前被完整读入。
  let warnedNoIp = false
  async function readRequestText(request) {
    if (!request.body) return ''
    const reader = request.body.getReader()
    const chunks = []; let n = 0
    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      n += value.byteLength
      if (n > hardBodyCap) { try { await reader.cancel() } catch { /* ignore */ } throw new TapeAPIError('BAD_REQUEST', 'request body too large') }
      if (n <= bodyLimit) chunks.push(value)
    }
    if (n > bodyLimit) throw new TapeAPIError('BAD_REQUEST', 'request body too large')
    const out = new Uint8Array(n); let o = 0
    for (const c of chunks) { out.set(c, o); o += c.byteLength }
    return new TextDecoder().decode(out)
  }

  async function handleRequest(request, { clientIp } = {}) {
    const url = new URL(request.url)
    const path = url.pathname.replace(/\/+$/, '') || '/'
    const json = (status, body, extra) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', ...CORS, ...extra } })
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS })
    if (request.method === 'GET' && path === '/.well-known/tapeapi.json') return json(200, manifest)
    if (request.method === 'GET' && path === '/tapeapi/v1/health') return json(200, health())
    const m = /^\/tapeapi\/v1\/([A-Za-z_][A-Za-z0-9_]{0,63})$/.exec(path)
    if (!m) return json(404, { ok: false, error: { code: 'NOT_FOUND', message: 'no such route' } })
    if (request.method !== 'POST') return json(405, { ok: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'use POST' } })
    if (delegationLapsed()) { stats.delegationLapsed++; return json(503, lapsedError()) }   // arch A3
    // Identity comes from the host (a Worker passes the edge's cf-connecting-ip as clientIp) or from a configured
    // proxy header -- never from a header the client could have written itself (runtime audit F-04).
    // 身份来自宿主（Worker 把边缘设置的 cf-connecting-ip 作为 clientIp 传入）或配置过的代理头，绝不来自客户端能自己写的头。
    const ip = clientIp || (clientIpHeader && headerIp(request.headers.get(clientIpHeader))) || 'unknown'
    if (!clientIp && !clientIpHeader && !warnedNoIp) { warnedNoIp = true; log('handleRequest called without clientIp and no clientIpHeader is set: every caller shares one rate-limit bucket') }
    const tooMany = (wait) => {
      stats.rateLimited++
      return json(429, { ok: false, error: { code: 'RATE_LIMITED', message: `too many requests; retry in ${wait}s`, data: { retryAfterS: wait } } }, { 'retry-after': String(wait) })
    }
    if (rl) { const wait = rateLimited(`ip:${ip}`, rl.ip); if (wait) return tooMany(wait) }
    let body
    try {
      const raw = await readRequestText(request)
      body = safeParseJSON(raw, { code: 'BAD_REQUEST' })
      if (!isPlainObject(body)) throw new TapeAPIError('BAD_REQUEST', 'body must be object')
    } catch (e) {
      const message = e instanceof TapeAPIError ? e.message : 'malformed request'
      if (rl) { const w = rateLimited(`free:${ip}`, rl.free); if (w) return tooMany(w) }   // unverified work / 未经验证的工作
      return json(/too large/.test(message) ? 413 : 400, envelope({ id: '', method: m[1], params: {} }, false, { code: 'BAD_REQUEST', message }, lastBlock))
    }
    const sentMethod = body.method
    body.method = m[1]
    let out
    try { out = await invoke(body, { ip, sentMethod }) }
    catch (e) {
      log('invoke crashed', e)
      // Bound to the same (id, params) the answer would have carried, so the client that sent it can verify it
      // (TAPI-21 §3.2, SD-1). / 与正常回答相同的 (id, params) 绑定，发出请求的客户端才能验证它。
      out = { status: 500, env: envelope(bindingOf(body, m[1]).req, false, { code: 'INTERNAL', message: 'internal error' }, lastBlock), paid: false }
    }
    if (out.rateLimited) return tooMany(out.rateLimited)
    if (out.unsigned) { if (out.refused) stats.escrowTokenRefused++; else stats.delegationLapsed++; return json(out.status, out.unsigned) }   // lapsed mid-request, or (3.0) the escrow token unconfirmed / 请求途中过期，或托管代币未确认
    const { status, env } = out
    stats.calls++
    bump(stats.byMethod, m[1])
    if (env?.ok) stats.ok++; else { stats.failed++; bump(stats.byCode, env?.error?.code || 'INTERNAL') }
    if (out.paid) stats.paid++; else stats.free++
    return json(status, env)
  }

  let server = null
  // `node:http` is imported here, not at module scope, so the rest of the runtime loads anywhere fetch exists.
  // listen() is the only Node-only entry point; Workers use handleRequest() instead.
  // `node:http` 在这里导入而不是在模块顶层，因此运行时的其余部分在任何有 fetch 的地方都能加载。
  // listen() 是唯一的 Node 专用入口；Workers 用 handleRequest()。
  async function listen(port = 0, host = '127.0.0.1') {
    // The escrow token check: refuse to start on an escrow of another token; anything else that kept the check from answering is said
    // 托管代币核对：托管代币不对就拒绝启动；其它没能核对的情况写进日志
    const tok = await checkEscrowToken()
    if (tok.status === 'mismatch' && !devMode) throw new TapeAPIError('UNSUPPORTED_PAYMENT_TOKEN', tok.message, { reason: 'escrow-token-mismatch', escrow: tok.escrow, token: tok.token, expected: tok.expected })
    if (tok.status !== 'ok' && tok.status !== 'skipped') log(`${tok.message}${tok.status === 'mismatch' ? ' (dev: starting anyway)' : ''}`)
    const { default: http } = await import('node:http')
    server = http.createServer(handler)
    // A request gets 30 s end to end, headers 15 s, instead of Node's 300 s default: a drip-fed body otherwise holds a
    // socket for five minutes (runtime audit I-02). / 整个请求 30 秒、请求头 15 秒，而不是 Node 默认的 300 秒。
    server.requestTimeout = opts.requestTimeoutMs ?? 30_000
    server.headersTimeout = Math.min(server.requestTimeout, opts.headersTimeoutMs ?? 15_000)
    return new Promise((resolve, reject) => server.once('error', reject).listen(port, host, () => resolve(server)))
  }
  function close() { return new Promise((r) => (server ? server.close(() => r()) : r())) }

  // 待结算凭证 / vouchers worth settling (latest per consumer). Expired ones are reported via log, not silently dropped.
  // A voucher signed by a session key settles only while BOTH it and the session are live (TAPI-22 §3.2), so its
  // deadline is min(expires, sessionExpiry); a consumer-signed voucher's deadline is its expires. Sorted soonest first.
  // 会话密钥签的凭证只有在凭证与会话都有效时才能结算，截止时间为 min(expires, sessionExpiry)；按截止时间升序。
  async function pendingSettlements() {
    if (typeof store.all !== 'function') throw new TapeAPIError('INTERNAL', 'store.all() not implemented')
    const t = now()
    const all = (await store.all()).filter(v => BigInt(v.cumulative) > 0n)
    const withDeadline = await Promise.all(all.map(async (v) => {
      let deadline = v.expires
      if (rpc && v.signer && !eqAddr(v.signer, v.consumer)) {
        try { deadline = Math.min(v.expires, Number(await sessionExpiry(v.consumer, v.signer))) } catch (e) { log('sessionExpiry read failed; using voucher expiry', e.message) }
      }
      return { ...v, deadline }
    }))
    const lost = withDeadline.filter(v => v.deadline < t)   // inclusive boundary: deadline == now still settles / 包含边界
    if (lost.length) log('expired unsettled vouchers', lost.map(v => `${v.consumer}:${v.cumulative}`).join(', '))
    return withDeadline.filter(v => v.deadline >= t).sort((x, y) => x.deadline - y.deadline)
      .map(({ consumer, provider, cumulative, expires, sig, deadline }) => ({ consumer, provider, cumulative, expires, sig, deadline }))
  }

  // What an operator must settle NOW (TAPI-22 §3.3.1): vouchers above what the escrow already paid whose deadline is
  // within `marginS`, and every voucher on a channel with an armed withdraw request (settle before availableAt).
  // The runtime holds no wallet: send each `settleTx(v)` with your own key, on a timer shorter than marginS.
  // 运营者此刻必须结算的：高于已结算额、且截止时间在 marginS 之内的凭证，以及所有挂着提现请求的通道上的凭证
  // （须在 availableAt 之前结算）。运行时不持有钱包：用你自己的密钥发送每个 `settleTx(v)`，定时周期短于 marginS。
  async function dueSettlements({ marginS = Math.max(2 * minVoucherLifeS, 600) } = {}) {
    needRpc()
    const t = now()
    const due = []
    for (const v of await pendingSettlements()) {
      // one consumer whose escrow cannot be read must not keep everyone else's vouchers from settling (review L-5)
      // 某个消费者的托管读不出来，不能挡住其他人的凭证结算
      let st
      try { st = await escrowState(v.consumer) } catch (e) { log(`dueSettlements: cannot read the escrow for ${v.consumer}, skipped this run`, e.message); continue }
      const { claimed, armed } = st
      if (BigInt(v.cumulative) <= claimed) continue            // already settled on chain / 链上已结算
      const reason = armed > 0n ? 'withdraw-requested' : v.deadline - t <= marginS ? 'deadline' : null
      if (reason) due.push({ ...v, reason })
    }
    return due
  }
  const settleTx = (v) => ({ to: escrow, data: encodeCall('settle', [v.consumer, v.provider, BigInt(v.cumulative), BigInt(v.expires), v.sig]), value: '0x0' })

  return { handler, handleRequest, listen, close, invoke, stats: () => ({ ...stats, byMethod: { ...stats.byMethod }, byCode: { ...stats.byCode }, uptimeS: Math.floor(Date.now() / 1000) - stats.started, delegationExpires: delegationExpires() }), pendingSettlements, dueSettlements, settleTx, contribution, currentBlock, checkEscrowToken, manifest, container, signer: signerAddr, escrow, chainId, store, rpc, version: VERSION, get server() { return server } }
}
